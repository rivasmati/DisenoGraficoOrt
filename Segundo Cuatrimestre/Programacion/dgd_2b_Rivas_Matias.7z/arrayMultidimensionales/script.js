//nro, nombre del auto, conductores, imagen, cantidad de victorias, orden en el video de presentación, característica

const autosLocos = [
    ["00", "Super Perraris", "Pierre Nodoyuna y Patán", "00.jpg", 0, 11, "Auto a reacción con armas ocultas"],
    [1, "El Rocomóvil", "Hermanos Macana: Pietro y Roco", "1.jpg", 3, 7, "El automóvil es un pedrusco gigante con ruedas"],
    [2, "El Espantomóvil", "Los Tenebrosos", "2.jpg", 3, 8, "Auto con un pequeño campanario habitado por un dragón"],
    [3, "El Auto/Súper Convertible", "Profesor Locovich", "3.jpg", 3, 5, "Auto con forma de barco con ruedas, que es capaz de transformarse casi en cualquier cosa."],
    [4, "El Stuka Rakuda", "Barón Hans Fritz", "4.jpg", 3,9, "Es un híbrido de coche y avión, capaz de volar limitadamente"],
    [5, "El Compact Pussycat", "Penélope Glamour", "5.jpg", 4, 6, "Auto de color rosa solo con accesorios maquilladores"],
    [6, "El Súper Chatarra Special", "Sargento Blast y el soldado Meekly", "6.jpg", 3, 3, "Es un vehículo militar, mitad tanque, mitad jeep"],
    [7, "La Antigualla Blindada", "Mafio y sus pandilleros", "7.jpg", 4, 4, "Sedán de los años 1920"],
    [8, "El Alambique Veloz", "Lucas el granjero y el Oso Miedoso", "8.jpg", 4, 10, "Carro de madera propulsado por una estufa de carbón"],
    [9, "El Superheterodino", "Pedro Bello", "9.jpg", 4, 1, "Es un drag racer con dos grandes ruedas traseras, con alta fragilidad"],
    [10, "El Troncoswagen", "Brutus y Listus", "10.jpg", 3, 2, "carreta de madera con sierras circulares en lugar de ruedas"]
]


